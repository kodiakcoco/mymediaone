const express = require('express');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000; // Use the PORT environment variable or default to 3000

app.use(express.static(__dirname));

// Serve the MyMedia.html file at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'MyMedia.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
